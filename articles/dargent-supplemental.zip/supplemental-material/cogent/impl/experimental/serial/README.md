An implementation of the mach/imx/serial.c in Cogent

NOTE: 
* Makefile needs to be given a path to `libutils` and `platsupport` in the `CFLAGS` variable for this to build.
* Update the include directives in `serial.ac` to reflect the proper path.
