# Test template
# Copy into `scripts' directory
source ../common/common.sh
set -e
start_test $1 $2

wd=`pwd`

# Add tests here
# Checksum format: `md5sum $wd/filename(s) >> $wd/../$2`
###


###

end_test
