/*
 * Copyright 2016, 
 *
 * This software may be distributed and modified according to the terms of
 * the GNU General Public License version 2. Note that NO WARRANTY is provided.
 * See "LICENSE_GPLv2.txt" for details.
 *
 * @TAG(_GPL)
 */

#ifndef LIB_ALLOCPOOL_H__
#define LIB_ALLOCPOOL_H__
extern struct kmem_cache *node_slab;

#endif /*! LIB_ALLOCPOOL_H__ */
