An implementation of loopback driver in the Linux kernel in Cogent.
The purpose of this driver is to illustrate the usage of Cogent to
implement a simple network driver interface. 
The focus of this implementation is verbosity and not efficiency.

