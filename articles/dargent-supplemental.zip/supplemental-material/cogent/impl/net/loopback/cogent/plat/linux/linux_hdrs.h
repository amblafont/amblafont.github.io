/*
 * Copyright 2018, 
 *  ()
 * .
 *
 * This software may be distributed and modified according to the terms of
 * the GNU General Public License version 2. Note that NO WARRANTY is provided.
 * See "LICENSE_GPLv2.txt" for details.
 *
 * @TAG(_GPL)
 */



#ifndef _LINUX_HDRS_H
#define _LINUX_HDRS_H

/*
 * Linux headers have to be included only if __KERNEL__ is defined because
 * Cogent's C parser does not support all gcc extensions in Linux headers.
 */
#ifdef __KERNEL__
#include <linux/kernel.h>
#include <linux/jiffies.h>
#include <linux/module.h>
#include <linux/interrupt.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/socket.h>
#include <linux/errno.h>
#include <linux/fcntl.h>
#include <linux/in.h>

#include <linux/uaccess.h>
#include <linux/io.h>

#include <linux/cpumask.h>
#include <linux/inet.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/skbuff.h>
#include <linux/ethtool.h>
#include <net/sock.h>
#include <net/checksum.h>
#include <linux/if_ether.h>     /* For the statistics structure. */
#include <linux/if_arp.h>       /* For ARPHRD_ETHER */
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/percpu.h>
#include <linux/net_tstamp.h>
#include <net/net_namespace.h>
#include <linux/u64_stats_sync.h>
#endif  /* __KERNEL__ */

#endif /* _LINUX_HDRS_H*/
