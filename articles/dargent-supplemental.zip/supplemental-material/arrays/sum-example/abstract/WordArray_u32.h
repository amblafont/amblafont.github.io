struct WordArray_u32 {
    int len;
    u32 *values;
};
typedef struct WordArray_u32 WordArray_u32;


