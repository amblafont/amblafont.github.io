


#include ".c"

SeedValue rand_with_seed(u64 s1) {
   u64 s2 = s1 * 1103515245 + 12345;
   SeedValue r = 
      // what else?
      { .seed = s2 , 
        .value = (unsigned int)(s2/65536) % 32768
      };

   return r;
}

