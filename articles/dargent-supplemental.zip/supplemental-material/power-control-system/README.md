Power control for STM32G4, reimplemented in cogent (section 5.1 of the paper)

Documentation: http://libopencm3.org/docs/latest/stm32g4/html/group__pwr__file.html
(Commit 470a1394a838fe308d886f6880b7054bab4aa5eb)

To generate the files: make
