import fileinput
import sys

folder =  sys.argv[1]
filename = f"{folder}/Generated_CorresSetup.thy"

utf8rep = {
   r"τ": r"\<tau>"
   , r"~": r"\<sim>"
   , r"∘": r"\<circ>"
   , r"λ": r"\<lambda>"
   , r"∃": r"\<exists>"
   , r"≡" :r"\<equiv>"
   , r"∧": r"\<and> "
   , r"‹": r"\<open>"
   , r"›": r"\<close>"
   , r"⟹": r"\<Longrightarrow>"
 }

def makeRep(dic, ss):
    d = {}
    for s in ss:
      for i, j in dic.items():
          d[i + s] = j + s
    return d

# c'est pour les poly types
rep = dict({
    r"(* Put manual type and value relations below here *)":
r"""
(* Put manual type and value relations below here *)
instantiation U29_C :: cogent_C_val
begin
definition type_rel_U29_C_def:
  "type_rel typ (_ :: U29_C itself) ≡ typ = RCon ''U29'' []"
definition val_rel_U29_C_def:
  "val_rel uv (x :: U29_C) ≡ (∃size v. (uv = UAbstract (UUN size v )) ∧ size = 29 ∧ v = unat (U29_C.v_C x) ∧ U29_C.v_C x < 2 ^ size) "
instance ..
end
"""

    , r'local_setup_val_rel_type_rel_put_them_in_buckets "main_pp_inferred.c" []': 
      r'local_setup_val_rel_type_rel_put_them_in_buckets "main_pp_inferred.c" [UAbstract "U29"]'

    , r'local_setup_heap_rel "main_pp_inferred.c" [] []':
      r'local_setup_heap_rel "main_pp_inferred.c" ["U29_C"] [("32 word", "w32")]'

      , r'(* Put manual value relation definitions below here *)':
      r"""(* Put manual value relation definitions below here *)
  val_rel_U29_C_def
  """

      , r'(* Put manual type relation definitions below here *)':
      r"""(* Put manual type relation definitions below here *)
  type_rel_U29_C_def
  """,
  r'local_setup ‹ local_setup_getter_correctness "main_pp_inferred.c" ›': "",
  r'(* Proving correctness of getters *)': "(* Getter specification is not supported when abstract types are involved *)"
#    r'local_setup ‹local_setup_getset_lemmas "main_pp_inferred.c" ›':
#    r"""local_setup ‹local_setup_getset_lemmas "main_pp_inferred.c" ›

# lemma t1_C_get_id_set_id[GetSetSimp] : "val_rel x v ⟹ val_rel x (deref_d4_get_id (deref_d6_set_id b v))"
#   sorry 
#   """
    })


def replace_all(text, dic):
    for i, j in dic.items():
        text = text.replace(i, j)
    return text

def replace_all_utf8(text, dic):
    for i, j in dic.items():
        text = text.replace(replace_all(i, utf8rep), replace_all(j, utf8rep))
    return text


with fileinput.FileInput(filename, inplace=True, backup='.bak') as file:
    for line in file:
        print(replace_all_utf8(line, rep), end='')
