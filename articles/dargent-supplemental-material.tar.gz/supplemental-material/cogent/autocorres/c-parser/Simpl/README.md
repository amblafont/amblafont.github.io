Simpl
=====

This directory contains Norbert Schirmer's Simpl language and associated VCG
tool. The code is covered by an LGPL licence.

See http://afp.sourceforge.net/entries/Simpl.shtml
