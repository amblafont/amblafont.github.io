/*
 * Copyright 2014, NICTA
 *
 * This software may be distributed and modified according to the terms of
 * the BSD 2-Clause license. Note that NO WARRANTY is provided.
 * See "LICENSE_BSD2.txt" for details.
 *
 * @TAG(NICTA_BSD)
 */

struct foo {
    int foo_1;
    int foo_2;
    int foo_3;
    int foo_4;
    int foo_5;
    int foo_6;
    int foo_7;
    int foo_8;
    int foo_9;
    int foo_10;
    int foo_11;
    int foo_12;
    int foo_13;
    int foo_14;
    int foo_15;
    int foo_16;
    int foo_17;
    int foo_18[300];
    int foo_20;
    int foo_19[20];
    int foo_21[64];
};
