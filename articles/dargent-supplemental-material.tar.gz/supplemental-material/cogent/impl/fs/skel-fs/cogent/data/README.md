This directory contains two files:

* defns.txt - A file containing a list of Cogent functions that are called externally.

* types.txt - A file containing a list of external type names to Cogent's C parser.

The names of the files could be anything, but ensure that the `Makefile`(one level above) reflects those changes in the `DEFNS` and `TYPES` variables.
