/*
 *
 * This software may be distributed and modified according to the terms of
 * the GNU General Public License version 2. Note that NO WARRANTY is provided.
 * See "LICENSE_GPLv2.txt" for details.
 *
 */

#ifndef FAKE_STDIO_H__
#define FAKE_STDIO_H__

typedef void FILE;

#define printf(...) (void)0

#endif